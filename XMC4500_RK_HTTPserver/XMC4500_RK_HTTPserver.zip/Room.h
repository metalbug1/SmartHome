/*********************************************************************/
/* Author         Date            Description						 */
/*-------------------------------------------------------------------*/
/* Alina&Mihai    14/05/2016    Initial version						 */
/*********************************************************************/


#ifndef _ROOM_H
#define _ROOM_H

#include "SmartHome_Types.h"

#define CURRENT_ROOM 		(LIVING)

#endif
